//
//  KPKArgon2IDKeyDerivation.h
//  KeePassKit
//
//  Created by Michael Starke on 11.01.21.
//  Copyright © 2021 HicknHack Software GmbH. All rights reserved.
//

#import "KeePassKit.h"

NS_ASSUME_NONNULL_BEGIN

@interface KPKArgon2IDKeyDerivation : KPKArgon2DKeyDerivation


@end

NS_ASSUME_NONNULL_END
