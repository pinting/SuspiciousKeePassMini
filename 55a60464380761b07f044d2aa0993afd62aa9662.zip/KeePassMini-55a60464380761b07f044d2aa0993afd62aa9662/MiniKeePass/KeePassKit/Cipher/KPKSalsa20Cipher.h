//
//  KPKSalsa20Cipher.h
//  KeePassKit
//
//  Created by Michael Starke on 04/11/2016.
//  Copyright © 2016 HicknHack Software GmbH. All rights reserved.
//

#import "KeePassKit.h"

@interface KPKSalsa20Cipher : KPKCipher

@end
