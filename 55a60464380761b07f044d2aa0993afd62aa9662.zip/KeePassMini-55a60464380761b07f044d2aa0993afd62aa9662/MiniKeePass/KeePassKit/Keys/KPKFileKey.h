//
//  KPKFileKey.h
//  KeePassKit
//
//  Created by Michael Starke on 07/09/16.
//  Copyright © 2016 HicknHack Software GmbH. All rights reserved.
//

#import "../Keys/KPKKey.h"

@interface KPKFileKey : KPKKey <NSSecureCoding>

@end
