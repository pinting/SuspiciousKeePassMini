//
//  KPKKdbWriter.h
//  KeePassKit
//
//  Created by Michael Starke on 25/10/2016.
//  Copyright © 2016 HicknHack Software GmbH. All rights reserved.
//

#import "KPKArchiver.h"

@interface KPKKdbArchiver : KPKArchiver

@end
