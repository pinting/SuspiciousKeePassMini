//
//  KPKWindowAssociation_Private.h
//  MacPass
//
//  Created by Michael Starke on 30/09/15.
//  Copyright © 2015 HicknHack Software GmbH. All rights reserved.
//

#import "KPKWindowAssociation.h"

@interface KPKWindowAssociation ()

@property (weak) KPKAutotype *autotype;

@end
