//
//  KPKChaCha20RandomStream.h
//  KeePassKit
//
//  Created by Michael Starke on 28/10/2016.
//  Copyright © 2016 HicknHack Software GmbH. All rights reserved.
//

#import "KPKRandomStream.h"

@interface KPKChaCha20RandomStream : KPKRandomStream

@end
