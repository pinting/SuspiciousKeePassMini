//
//  KPKKdbTreeUnarchiver.h
//  KeePassKit
//
//  Created by Michael Starke on 25/10/2016.
//  Copyright © 2016 HicknHack Software GmbH. All rights reserved.
//

#import "KPKUnarchiver.h"

@interface KPKKdbUnarchiver : KPKUnarchiver

@end
