Homepage: http://chacha20.insanecoding.org/
Articles: http://insanecoding.blogspot.com/

ChaCha20 is a stream cipher created by Daniel Bernstein (http://cr.yp.to/chacha.html).
This implementation focuses on simplicity and correctness.
Test vectors with a battery of unit tests are included.

See chacha_simple.h for a list of functions and description.
