protocol PasswordSelectionDelegate: class {
    func selectedPassword(for domain: Directory)
}

